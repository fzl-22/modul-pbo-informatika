package classes;

public class Handphone {
  public String pemilik;
  public String merk;
  public double ukuranLayar;

  public void hidupkanHandphone(){
    System.out.println("Hidupkan Handphone" + " " + merk);;
  }

  public String matikanHandphone(){
    return "Matikan Handphone";
  }
}
